'''Crea un diccionario vacío llamado perro
Agregue nombre, color, raza, patas
y edad al diccionario de perros'''

perro = {
    
}

perro.update({
    'nombre': 'Raro',
    'color': 'verde',
    'patas': '3',
    'edad': '1.5'
})