'''Calculadora de calificaciones: Crea un programa que solicite al usuario ingresar nombres de estudiantes y sus calificaciones, y luego genere un diccionario 
donde los nombres son las claves y las calificaciones son los valores (estas calificaciones tienen que ser una lista de notas de cada estudiante).
El programa debe permitir al usuario buscar las calificaciones de un estudiante específico.


Sobre el ejercicio anterior, calcula la media de cada estudiante y guarda la media de cada uno en un nuevo diccionario.
Una vez calculada la media de cada alumno realiza las siguientes acciones:
Crea una lista con los alumnos con medias inferiores a 5 y otra con notas iguales o superiores a 5.
Calcula la media global de la clase
Modifica la media de cada alumno por: Insuficiente si la media es menor que 5, Notable si está en 5 y 8 y Sobresaliente si la nota es mayor de 8.
Crea un nuevo diccionario en el que la clave sea Insuficiente, Notable o Sobresaliente y el valor el numero de alumnos que tienen esas calificaciones.'''

n = int(input('Cuantos alumnos tienes? '))

cuaderno_notas = {}

for lista in range(1, n+1):
    nombre = input(f'Ingresa el nombre del alumno {lista}: ')
    
    notas = {
            'Lengua': int(input("Ingrese nota de Lengua: ")),
            'Matemática': int(input("Ingrese nota de Matemática: ")),
            'Física': int(input("Ingrese nota de Física: ")),
            'Química': int(input("Ingrese nota de Química: ")),
            'Historia': int(input("Ingrese nota de Historia: "))
        }

    media_total = sum(notas.values()) / len(notas)

    notas.update({
        'Media total' : media_total
    })

    cuaderno_notas[nombre] = notas

print(f'Cuaderno de notas: {cuaderno_notas}')