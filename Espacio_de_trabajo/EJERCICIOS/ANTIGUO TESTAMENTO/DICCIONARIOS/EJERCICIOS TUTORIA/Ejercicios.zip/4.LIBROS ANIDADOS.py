'''Diccionario Anidado: Crea un diccionario anidado que contenga
información sobre libros (título, autor, año de publicación).'''



libros = {
    'libro1': {
        'titulo': 'Fray Perico y su borrico',
        'autor': 'Juan Muñoz Martín',
        'año de publicación': '1980'
    },
    'libro2':{
        'titulo': 'Colmillo Blanco',
        'autor': 'Jack London',
        'año de publicación': '1906'
    }
    }

