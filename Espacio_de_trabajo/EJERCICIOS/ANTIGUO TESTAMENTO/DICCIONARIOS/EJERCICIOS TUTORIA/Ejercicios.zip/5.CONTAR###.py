'''Contar Caracteres: Crea un diccionario que cuente la frecuencia
de cada carácter en una cadena de texto.'''


texto = 'Hola mundo.'
